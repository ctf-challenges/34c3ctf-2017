#!/bin/bash
docker build -t saelo/v9 .
