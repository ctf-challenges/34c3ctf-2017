#!/bin/bash

# --privileged to enable debugging
docker run -it --privileged --name v9 saelo/v9
