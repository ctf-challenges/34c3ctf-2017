the filesystem is mounted on the test_dir folder in the home folder of the user

PSA: the filesystem is not meant to be a production grade filesystem and only supports basic operations, as such don't expect to do anything more than really basic things on it :)

you can connect to remote using socat tcp4:178.63.8.31:4242 -,raw,echo=0

the flag is at the root of the home folder

Create the basebox using
    cd basebox
    ./build.sh

and spawn a victim vm using
    cd victimbox
    vagrant up
    vagrant ssh

