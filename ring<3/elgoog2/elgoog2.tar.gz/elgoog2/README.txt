## How this challenge works

Contact: niklasb in IRC

You send me an email with subject `Layoffs Q1 2018` to 34c3elgoog@gmail.com.
It should contain an attachment named "Layoffs Q1 2018.zip" (including spaces,
excluding quotes), encrypted with the password "openme!" (excluding quotes).
This archive should contain a single file called "Layoffs Q1 2018.pdf.exe"
(including spaces, excluding quotes).

Your email should at least contain the following text, in the precise format shown
below:

```
Token: <your team token from challenge description, example: 123:77ba9cd915c8e359d9733edcfe9c61e5aca92afb>
Contact: <some way to contact you, preferrably IRC or email>
```

TL;DR: I will now run your exploit 3 times as an unprivileged LOW INTEGRITY(!)
process on a Windows 10 RS3 VM with the elgoog.sys driver active and no network
connection.  I will reboot between tries. If it prints the contents of the file
C:\token.txt (readable only by SYSTEM), you get a solve.

NOTE THAT THIS CHALLENGE USES A SLIGHTLY DIFFERENT VERSION OF THE elgoog.sys
DRIVER THAN elgoog1!!


## Full description

Here is *precisely* what I will do with your file (possibly replacing steps 0-6
by a VM snapshot restore):

0. Download VMware image from [1]
1. Import VM into VMware Workstation 14
2. Change VM settings to 4096 MB RAM, 2 processors with 1 core each
3. Install all Windows updates
4. Set a strong password for the default user
5. As Administrator:
    * Enable test signing mode via `bcdedit /set testsigning on`
    * Copy token file and driver file to the VM, so we will have:

      C:\token.txt
      C:\Windows\System32\Drivers\elgoog.sys (SHA-1: b1b2c83de118ea17db6f07043046b90d93554047)

    * Set file permissions for C:\token.txt to be only readable, and
      only by SYSTEM
    * Create a new user named "Clueless Employee" (no quotes) with empty
      password via the method described in [2]
    * Use OSRLOADER to load the elgoog.sys driver at boot

6. Log in as the new user
7. Save your file as "C:\elgoog\Layoffs Q1 2018.pdf.exe"
8. Run as Administrator:

    icacls "C:\elgoog\Layoffs Q1 2018.pdf.exe" /setintegritylevel low

9. Reboot
10. Wait 2 minutes
11. Disable network adapter
12. In a user terminal:

    "C:\elgoog\Layoffs Q1 2018.pdf.exe"

If the contents of the file C:\token.txt appear within 30 seconds (it consists
of less than hundred ASCII characters and maybe some trailing whitespace) and
the VM does not crash within the following 30 seconds, you win and I will add
a flag submission for your team, with the timestamp of the email that
I received. In any case, I will reply with a short feedback for every
submission that I consider a serious attempt.

I will try steps 9-12 a total of 3 times before I give up.

I will not accept more than 3 emails per team. If you really need more, you
will need to explain to me in detail why you messed up your first 3 tries and
convince me that you deserve a 4th chance.

--
[1]: https://developer.microsoft.com/en-us/windows/downloads/virtual-machines
[2]: https://support.microsoft.com/en-gb/help/4026923/windows-create-a-local-user-or-administrator-account-in-windows-10
